Multilevel : *time = 4-priority

Simple Schedule : schedule.c :
  Take a PCB and enqueue it.
  
  
Simple Round Robin adds a new feature (time)
  (You need to do one thing for SRR vs SS --> assigning time 4.)


Queue array pointer (priority will be the index.)

In init : Constructor for scheduler (NULL values, etc);

New multi-level : New thing : age, and new function void age();
