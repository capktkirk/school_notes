Project 5 :

Develop a multithreaded application that resolves domain names to IP addresses, similar to the operation preformed each time you access a new website in your web browser. The application is composed of two sub-systems, each with

Given a bunch of code : lookup.c a nonthreaded fully functional code.

provided non-thread queue or you can build your own bounded buffer.

hello_world pthread assignment.
queueTest

Nothing in the code. It's a blank file.

Modify the nonthreaded one. 

Do not trust the results-ref.txt that is given, generate a new one.

Pass in all input files, the last thing will be the output file.

pass it twice.

REquest Thread Pool will open the files into the request queue and writ einto a shared file.

At least one requester thread.

1 total requester or one requester per file.

Minimum of two resolver threads.

Main thread, requestor thread, and two resolver threads (4 at least)

Error Handling : (The code that is given does all the error checking that needs to be done.)

Only libraries allowed are in External Resources

Assignments 5 and 6 build on each other.

Extra Credit : 

Multiple IP addresse
IPv6 Support and Testing
Easy*Matching Number of Threads to Number of Cores
Full-Loop Lookups
Benchmarks
Conditional Variables
Conditional Variables in C11 or Newer
Go : Implement the assignment in Go using Go's thread-safe channels and threads.

Once the assignment works, then do extra credit.

char buf[size][sbufsize] is a way to do the shared memory thing.

