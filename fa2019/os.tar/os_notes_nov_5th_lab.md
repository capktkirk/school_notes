Post Midterm :
