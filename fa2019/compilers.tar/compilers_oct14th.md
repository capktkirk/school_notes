Finish up stuff about P3

Template function

template<typename BINOP, Operator_type NM>
Expression* Bin_op_check(Expression* one, Expression* three, unisgned int valid_types){
    //10-15 class notes.
}
