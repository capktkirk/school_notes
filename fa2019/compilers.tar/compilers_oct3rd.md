constfunctions

#include<iostream>
#include "Date.h"

using namespace std;

void showme(Date dr){

