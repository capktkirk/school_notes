No class during next week?

Changes to the project :
  
